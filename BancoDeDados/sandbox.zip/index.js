var express = require("express");
var app = express();
var port = process.env.PORT || 3000;

var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

var sqlite3 = require("sqlite3").verbose();
var caminhoBanco = "BancoDadosAppoef.db";
var banco = new sqlite3.Database(caminhoBanco);

app.get("/", function (req, res) {
  res.send("Agora foi");
});
app.listen(port, () => {
  //comando que permite o node escutar os dados que estão sendo enviados
  console.log("Servidor rodando!" + port);
});
app.post("/cadastrarPergunta", function (req, res) {
  let Questao = req.body.Questao;
  let idRespA = req.body.idRespA;
  let textRespA = req.body.textRespA;
  let idRespB = req.body.idRespB;
  let textRespB = req.body.textRespB;
  let idRespC = req.body.idRespC;
  let textRespC = req.body.textRespC;
  let RespCorreta = req.body.RespCorreta;

  banco.run(
    `INSERT INTO Prova (Questao, idRespA, textRespA, idRespB, textRespB, idRespC, textRespC, RespCorreta)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      Questao,
      idRespA,
      textRespA,
      idRespB,
      textRespB,
      idRespC,
      textRespC,
      RespCorreta,
    ],
    function (err) {
      if (err) {
        return res.status(500).send(err.message);
      }
      return res.send("Pergunta cadastrada");
    }
  );
});
app.get("/perguntaCadastrada", function (req, res) {
  banco.all(`SELECT * FROM Prova`, [], (err, rows) => {
    if (err) {
      return res.send(err);
    }
    return res.json(rows);
  });
});
app.get("/randomPerguntas", function (req, res) {
  banco.all(
    `SELECT * FROM Prova ORDER BY random() LIMIT 5;`,
    [],
    (err, rows) => {
      if (err) {
        return res.status(500).send({ error: "Erro ao buscar perguntas" });
      }
      let provaRandom = new Set(rows);
      return res.json(Array.from(provaRandom));
    }
  );
});
// Criar login
app.post("/criarLogin", function (req, res) {
  let usuario = req.body.usuario;
  let senha = req.body.senha;

  banco.all(
    `INSERT INTO Login (usuario, senha)
     VALUES (?, ?)`,
    [usuario, senha],
    function (err) {
      if (err) {
        res.send(err);
      }
      res.send("Usuario cadastrado");
    }
  );
});
// Visializar cadastros
app.get("/usuariosCadastrados", function (req, res) {
  banco.all(`SELECT * FROM Login`, [], (err, rows) => {
    if (err) {
      res.send(err);
    }
    res.send(rows);
  });
});
// deletar informações
app.delete("/deletar", function (req, res) {
  banco.all(`DELETE FROM Login`, [], (err, rows) => {
    if (err) {
      res.send(err);
    }
    res.send(rows);
  });
});
