var express = require("express"); // carrega o servidor em uma variável
var app = express(); // biblioteca express - variável com a função express
var port = process.env.PORT || 3000; // conexão web

app.get("/", function (req, res) {
  res.send("Agora foi");
});

var bodyParser = require("body-parser");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// Banco de dados
var sqlite3 = require("sqlite3").verbose();
var caminhoBanco = "BancoDadosAppoef.db"; //variável recebe o caminho
var banco = new sqlite3.Database(caminhoBanco);

//
app.post("/criarPerguntas", function (req, res) {
  let Questao = req.body.Questao;
  let idRespA = req.body.idRespA;
  let textRespA = req.body.textRespA;
  let idRespB = req.body.idRespB;
  let textRespB = req.body.textRespB;
  let idRespC = req.body.idRespC;
  let textRespC = req.body.textRespC;
  let idRespD = req.body.idRespD;
  let textRespD = req.body.textRespD;
  let idRespE = req.body.idRespE;
  let textRespE = req.body.textRespE;
  let RespCorreta = req.body.RespCorreta;

  banco.all(
    `INSERT INTO Prova (Questao, idRespA, textRespA, idRespB, textRespB, idRespC, textRespC, idRespD, textRespD, idRespE, textRespE, RespCorreta)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      Questao,
      idRespA,
      textRespA,
      idRespB,
      textRespB,
      idRespC,
      textRespC,
      idRespD,
      textRespD,
      idRespE,
      textRespE,
      RespCorreta,
    ],
    function (err) {
      if (err) {
        res.send(err);
      }
      res.send("Pergunta cadastrada");
    }
  );
});

app.get("/perguntasCadastradas", function (req, res) {
  banco.all(`SELECT * FROM Prova`, [], (err, rows) => {
    if (err) {
      res.send(err);
    }
    res.send(rows);
  });
});

// Criar login
app.post("/criarLogin", function (req, res) {
  let usuario = req.body.usuario;
  let senha = req.body.senha;

  banco.all(
    `INSERT INTO Login (usuario, senha)
     VALUES (?, ?)`,
    [usuario, senha],
    function (err) {
      if (err) {
        res.send(err);
      }
      res.send("Usuario cadastrado");
    }
  );
});

// Visializar cadastros
app.get("/usuariosCadastrados", function (req, res) {
  banco.all(`SELECT * FROM Login`, [], (err, rows) => {
    if (err) {
      res.send(err);
    }
    res.send(rows);
  });
});

// deletar informações
app.delete("/deletar", function (req, res) {
  banco.all(`DELETE FROM Login`, [], (err, rows) => {
    if (err) {
      res.send(err);
    }
    res.send(rows);
  });
});

app.listen(port, () => {
  //comando que permite o node escutar os dados que estão sendo enviados
  console.log("Servidor rodando!" + port);
});
